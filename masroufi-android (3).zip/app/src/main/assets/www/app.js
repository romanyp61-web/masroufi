/*
 * مصروفي — الواجهة v2
 * تنفيذ وتطوير Romany fawzy
 */
(function () {
  'use strict';
  const L = window.Masroufi;
  const IC = window.MIcons;
  const KEY = 'masroufi:v1';
  const CREDIT = 'تنفيذ وتطوير Romany fawzy';
  const VERSION = '2.2';
  const reduceMotion = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);

  /* ---------- حفظ البيانات ---------- */
  let memoryOnly = false;
  function load() {
    try {
      const t = localStorage.getItem(KEY);
      if (t) {
        const d = JSON.parse(t);
        if (d && Array.isArray(d.months)) {
          d.settings = Object.assign(L.defaultSettings(), d.settings || {});
          return d;
        }
      }
    } catch (e) { memoryOnly = true; }
    return L.emptyState();
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { memoryOnly = true; }
  }
  let S = load();
  const ui = { tab: 'home', sheet: null, dialog: null, toast: null, animate: true, enter: false, histFilter: 'all' };

  /* ---------- أدوات ---------- */
  const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  const DAYS = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = (n) => {
    const v = L.round2(n);
    const s = Math.abs(v).toLocaleString('en-US', { minimumFractionDigits: Number.isInteger(v) ? 0 : 2, maximumFractionDigits: 2 });
    return (v < 0 ? '−' : '') + s;
  };
  const num = (n) => '<span class="num">' + fmt(n) + '</span>';
  const neg = (n) => '<span class="num">' + (n ? '−' : '') + fmt(n) + '</span>';
  const pos = (n) => '<span class="num">+' + fmt(n) + '</span>';
  const money = (n) => num(n) + ' <small>ج.م</small>';
  const ic = (n, s) => IC.svg(n, s);
  const tile = (inner, color, cls) => '<span class="tile' + (cls ? ' ' + cls : '') + '" style="--c:' + esc(color || 'var(--brand)') + '">' + inner + '</span>';
  const catGlyph = (c, s) => (IC.resolve(c.icon) ? ic(c.icon, s || 22) : '<span aria-hidden="true">' + esc(c.icon) + '</span>');
  const catTile = (c, cls) => tile(catGlyph(c), c.color, cls);
  const OBL_ICON = { o_housing: 'building', o_rent: 'key', o_gam3iya: 'users' };
  const OBL_COLOR = { o_housing: '#6C5CE7', o_rent: '#0E8579', o_gam3iya: '#D8851C' };
  const tplOf = (id) => S.settings.obligations.find((x) => x.id === id);
  const oblTile = (id, cls) => tile(ic((tplOf(id) && tplOf(id).icon) || OBL_ICON[id] || 'wallet', 22), OBL_COLOR[id] || '#3D7EDB', cls);

  function dateAr(s, withYear) {
    const [y, m, d] = s.split('-').map(Number);
    return d + ' ' + MONTHS[m - 1] + (withYear || y !== new Date().getFullYear() ? ' ' + y : '');
  }
  function dayLabel(s, today) {
    const d = L.diffDays(s, today);
    if (d === 0) return 'النهاردة';
    if (d === 1) return 'امبارح';
    return dateAr(s);
  }
  function weekdayDate(s) {
    const [y, m, d] = s.split('-').map(Number);
    return DAYS[new Date(y, m - 1, d).getDay()] + ' ' + d + ' ' + MONTHS[m - 1];
  }
  function parseAmt(v) {
    let s = String(v == null ? '' : v).trim()
      .replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
      .replace(/٫/g, '.').replace(/،/g, ',').replace(/\s/g, '');
    s = s.replace(/,(?=\d{3}(\D|$))/g, '').replace(/,/g, '.');
    if (!/^\d*\.?\d+$|^\d+\.$/.test(s)) return NaN;
    return Number(s);
  }
  const addDays = (s, n) => {
    const [y, m, d] = s.split('-').map(Number);
    return L.todayStr(new Date(y, m - 1, d + n));
  };
  const $ = (s, r) => (r || document).querySelector(s);
  const val = (id) => { const e = document.getElementById(id); return e ? e.value : ''; };
  const openMonth = () => S.months.find((m) => !m.closed) || null;
  const lastClosed = () => { for (let i = S.months.length - 1; i >= 0; i--) if (S.months[i].closed) return S.months[i]; return null; };
  const catOf = (id) => S.settings.categories.find((c) => c.id === id) || { id, name: 'بند محذوف', icon: 'receipt', color: '#7B8794' };
  const PALETTE = ['#E8833A', '#2FA6D6', '#D6453D', '#F0A500', '#6C5CE7', '#14877D', '#3D7EDB', '#C2549A', '#8A6D3B', '#7B8794', '#2E9E5B', '#B5527A'];
  const buzz = () => { try { if (navigator.vibrate) navigator.vibrate(12); } catch (e) { /* مش مهم */ } };

  function mutate(fn, msg) {
    const prev = JSON.stringify(S);
    const i = S.months.findIndex((m) => !m.closed);
    S.months[i] = fn(S.months[i]);
    save();
    render();
    if (msg) toast(msg, { undo: () => { S = JSON.parse(prev); save(); render(); } });
  }

  /* ---------- طبقات النوافذ (كل طبقة بتترسم لوحدها) ---------- */
  function layers() {
    const l = $('#layer');
    if (!l.firstChild) l.innerHTML = '<div id="sheetLayer"></div><div id="dialogLayer"></div><div id="toastLayer"></div>';
  }
  let toastTimer;
  function toast(msg, o) {
    o = o || {};
    ui.toast = { msg, undo: o.undo, kind: o.kind || 'ok' };
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { ui.toast = null; paintToast(); }, o.undo ? 6000 : 4000);
    paintToast();
  }
  function paintToast() {
    layers();
    const t = ui.toast;
    $('#toastLayer').innerHTML = t ? '<div class="toast ' + t.kind + '" role="status">' + ic(t.kind === 'error' ? 'alert' : 'check-circle', 22) + '<span>' + esc(t.msg) + '</span>' + (t.undo ? '<button data-act="undo">تراجع</button>' : '') + '</div>' : '';
  }
  function confirmDlg(o) {
    return new Promise((res) => { ui.dialog = Object.assign({}, o, { res }); paintDialog(); });
  }
  function paintDialog() {
    layers();
    const d = ui.dialog;
    $('#dialogLayer').innerHTML = d ? '<div class="scrim center" data-act="dlg-scrim"><div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="dlg-t">' +
      tile(ic(d.icon || 'alert', 28), d.danger ? 'var(--over)' : 'var(--brand)', 'lg') + '<h3 id="dlg-t">' + esc(d.title) + '</h3><p>' + esc(d.text || '') + '</p>' +
      '<div class="two"><button class="btn ghost" data-act="dlg-no">إلغاء</button><button class="btn ' + (d.danger ? 'danger' : '') + '" data-act="dlg-yes">' + esc(d.ok || 'تمام') + '</button></div></div></div>' : '';
    if (d) { const y = $('#dialogLayer [data-act=dlg-no]'); if (y) y.focus(); }
  }
  function closeDialog(ans) {
    const d = ui.dialog;
    ui.dialog = null; paintDialog();
    if (d && d.res) d.res(ans);
  }

  /* ---------- المظهر ---------- */
  function applyTheme() {
    const t = S.settings.theme;
    if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t;
    else delete document.documentElement.dataset.theme;
    requestAnimationFrame(() => {
      const bg = getComputedStyle(document.documentElement).getPropertyValue('--bg').trim();
      const m = document.querySelector('meta[name="theme-color"]');
      if (m && bg) m.setAttribute('content', bg);
    });
  }

  /* ---------- مكونات مشتركة ---------- */
  const sec = (title, action) => '<div class="sec"><h2>' + title + '</h2>' + (action || '') + '</div>';
  const goLink = (tab, label) => '<button class="link" data-act="tab" data-v="' + tab + '">' + label + '</button>';
  const credit = () => '<p class="credit">' + esc(CREDIT).replace('Romany fawzy', '<b>Romany fawzy</b>') + '</p>';
  const pageHead = (title, sub) => '<header class="top"><div><h1>' + title + '</h1><p class="sub">' + sub + '</p></div></header>';
  const empty = (icon, title, text, btn) => '<div class="empty">' + tile(ic(icon, 26), 'var(--ink-3)', 'lg') + '<b>' + title + '</b><span>' + text + '</span>' + (btn || '') + '</div>';

  function sheetShell(title, body, footer) {
    return '<div class="grab"></div><div class="sh-head"><h3>' + title + '</h3><button class="icon-btn" data-act="close-sheet" aria-label="إغلاق">' + ic('close', 22) + '</button></div>' +
      '<div class="sh-body">' + body + '</div>' + (footer ? '<div class="sh-foot">' + footer + '</div>' : '');
  }

  /* ---------- العداد ---------- */
  function countUp(el, to) {
    const final = el.textContent;
    el.dataset.counting = '1';
    const t0 = performance.now(), dur = 750;
    const tick = (t) => {
      const k = Math.min(1, (t - t0) / dur);
      const e = 1 - Math.pow(1 - k, 3);
      if (k < 1) { el.textContent = fmt(Math.round(to * e)); requestAnimationFrame(tick); }
      else { el.textContent = final; delete el.dataset.counting; }
    };
    requestAnimationFrame(tick);
  }

  /* ---------- الشاشات ---------- */
  const STATE_TXT = { good: 'وضعك كويس', warn: 'خلّي بالك', low: 'قرّبت تخلّص', over: 'الفلوس خلصت وزيادة' };

  function viewHome(m) {
    const today = L.todayStr();
    const t = L.totals(m);
    const o = L.overview(m);
    const dl = L.daysLeft(m, today);
    const over = o.remaining < 0;
    const big = over ? -o.remaining : o.remaining;
    const cats = L.byCategory(m);
    const recent = recentEntries(m).slice(0, 4);
    const due = m.obligations.filter((x) => x.amount > 0 && !x.paid);

    const header = '<header class="top"><div class="brand-mark"><span class="logo-sm">' + ic('wallet', 22) + '</span><div><h1>مصروفي</h1><p class="sub">' + weekdayDate(today) + '</p></div></div></header>';

    const spentW = Math.max(0, o.spent), unpaidW = Math.max(0, o.unpaid), freeW = Math.max(0, o.free);
    const tot = (spentW + unpaidW + freeW) || 1;
    const hero = '<section class="hero2 st-' + o.status + '" aria-label="ملخص الفلوس">' +
      '<div class="meta"><span>' + ic('calendar', 15) + dateAr(m.startDate) + (m.nextPayday ? ' ← ' + dateAr(m.nextPayday) : '') + '</span><span>' + ic('clock', 15) + 'القبض بعد <b class="num">' + dl + '</b> يوم</span></div>' +
      '<div class="lbl">' + (over ? 'عليك' : 'الباقي') + '</div><span class="big"><span class="bn num" data-v="' + big + '">' + fmt(big) + '</span><small>ج.م</small></span>' +
      '<div class="of">من <span class="num">' + fmt(o.available) + '</span> جنيه · ' + STATE_TXT[o.status] + '</div>' +
      '<div class="ribbon" aria-hidden="true"><i class="rs" style="flex:' + spentW / tot + ' 1 0"></i><i class="ro" style="flex:' + unpaidW / tot + ' 1 0"></i><i class="rf" style="flex:' + freeW / tot + ' 1 0"></i></div>' +
      '<div class="legend3"><div style="--d:var(--accent)"><div class="k">اتصرف</div><div class="v">' + num(o.spent) + '</div></div>' +
      '<div style="--d:#A79CFF"><div class="k">التزامات لسه</div><div class="v">' + num(o.unpaid) + '</div></div>' +
      '<div style="--d:#5CE6B4"><div class="k">حر بعد الالتزامات</div><div class="v">' + num(o.free) + '</div></div></div></section>';

    const usage = {}; m.expenses.forEach((e) => { usage[e.cat] = (usage[e.cat] || 0) + 1; });
    const ordered = S.settings.categories.map((c, i) => ({ c, i })).sort((a, b) => (usage[b.c.id] || 0) - (usage[a.c.id] || 0) || a.i - b.i).map((x) => x.c);
    const quick = '<section class="quick" aria-label="تسجيل سريع"><div class="qrail">' + ordered.map((c) => '<button class="qc" style="--c:' + esc(c.color) + '" data-act="open-add" data-cat="' + esc(c.id) + '">' + catTile(c) + '<span>' + esc(c.name) + '</span></button>').join('') + '</div></section>';

    const upcoming = sec('الجاي عليك', due.length ? goLink('bills', 'كل الالتزامات') : '') + '<div class="card">' + (due.length ?
      due.slice(0, 3).map((x) => '<button class="row" data-act="tab" data-v="bills">' + oblTile(x.id) + '<span class="main"><span class="t">' + esc(x.name) + '</span><span class="s">' + esc(oblNote(x) || 'مستحق الشهر ده') + '</span></span><span class="amt">' + num(x.amount) + '</span></button>').join('') :
      '<div class="row">' + tile(ic('check-circle', 22), 'var(--good)') + '<span class="main"><span class="t">' + (m.obligations.some((x) => x.amount > 0) ? 'كل التزامات الشهر ده اتدفعت' : 'مفيش التزامات متسجلة الشهر ده') + '</span></span></div>') + '</div>';

    const ledger = sec('حساب الشهر') + '<div class="card"><ul class="ledger">' +
      '<li><span class="k">المرتب</span><span class="v">' + num(t.salary) + '</span></li>' +
      (t.carry !== 0 ? '<li class="' + (t.carry < 0 ? 'neg' : '') + '"><span class="k">' + (t.carry < 0 ? 'عليك من الشهر اللي فات' : 'مرحّل من الشهر اللي فات') + '</span><span class="v">' + num(t.carry) + '</span></li>' : '') +
      (t.extrasTotal ? '<li class="pos"><span class="k">دخل إضافي</span><span class="v">' + pos(t.extrasTotal) + '</span></li>' : '') +
      '<li class="neg"><span class="k">اتصرف</span><span class="v">' + neg(t.expensesTotal) + '</span></li>' +
      (t.obligationsPaid ? '<li class="neg"><span class="k">التزامات اتدفعت</span><span class="v">' + neg(t.obligationsPaid) + '</span></li>' : '') +
      '<li class="total"><span class="k">الباقي</span><span class="v">' + money(t.remaining) + '</span></li></ul></div>';

    const spending = cats.length ? sec('اتصرف فين') + donutCard(cats, t.expensesTotal) : '';

    const recentSec = sec('آخر العمليات', recent.length ? goLink('log', 'السجل كله') : '') + (recent.length ?
      '<div class="card">' + recent.map((r) => entryRow(r, today, false)).join('') + '</div>' :
      '<div class="card">' + empty('receipt', 'لسه مفيش عمليات', 'دوس على زرار + وسجّل أول مصروف.', '<button class="btn sm" data-act="open-add">' + ic('plus', 20) + 'سجّل مصروف</button>') + '</div>');

    return header + hero + quick + upcoming + recentSec + '<details class="more-d"><summary>تفاصيل الشهر</summary>' + ledger + spending + '</details>' + credit();
  }

  function donutCard(cats, total) {
    const top = cats.slice(0, 4);
    const rest = cats.slice(4);
    const segs = top.map((c) => ({ name: catOf(c.cat).name, color: catOf(c.cat).color, total: c.total }));
    if (rest.length) segs.push({ name: 'أخرى', color: '#7B8794', total: L.sum(rest.map((c) => c.total)) });
    const R = 46, C = 2 * Math.PI * R;
    let off = 0, circles = '';
    segs.forEach((s) => {
      const share = s.total / total;
      const len = Math.max(1, share * C - 2.5);
      circles += '<circle cx="60" cy="60" r="' + R + '" fill="none" stroke="' + esc(s.color) + '" stroke-width="14" stroke-dasharray="' + len.toFixed(2) + ' ' + (C - len).toFixed(2) + '" stroke-dashoffset="' + (-off).toFixed(2) + '"/>';
      off += share * C;
    });
    return '<div class="card donut-wrap"><div class="donut"><svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="' + R + '" fill="none" stroke="var(--surface-2)" stroke-width="14"/>' + circles + '</svg>' +
      '<div class="mid"><b class="num">' + fmt(total) + '</b><span>مصروفات</span></div></div><div class="legend">' +
      segs.map((s) => '<div class="lg" style="--c:' + esc(s.color) + '"><span class="dot"></span><span class="nm">' + esc(s.name) + '</span><span class="pc num">' + Math.round(s.total / total * 100) + '%</span></div>').join('') + '</div></div>';
  }

  function recentEntries(m) {
    const all = [];
    m.expenses.forEach((e) => all.push({ kind: 'expenses', id: e.id, date: e.date, amount: e.amount, cat: e.cat, note: e.note }));
    m.extras.forEach((e) => all.push({ kind: 'extras', id: e.id, date: e.date, amount: e.amount, source: e.source }));
    m.obligations.forEach((o) => { if (o.paid && o.amount > 0) all.push({ kind: 'oblig', id: o.id, date: o.paidDate || m.startDate, amount: o.amount, name: o.name }); });
    all.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
    return all;
  }

  function entryRow(r, today, deletable) {
    let lead, title, sub, amt;
    if (r.kind === 'expenses') { const c = catOf(r.cat); lead = catTile(c); title = c.name; sub = (r.note ? r.note + ' · ' : '') + dayLabel(r.date, today); amt = '<span class="amt">' + neg(r.amount) + '</span>'; }
    else if (r.kind === 'extras') { lead = tile(ic('coins', 22), 'var(--good)'); title = r.source || 'دخل إضافي'; sub = 'دخل إضافي · ' + dayLabel(r.date, today); amt = '<span class="amt in">' + pos(r.amount) + '</span>'; }
    else { lead = oblTile(r.id); title = r.name; sub = 'التزام اتدفع · ' + dayLabel(r.date, today); amt = '<span class="amt">' + neg(r.amount) + '</span>'; }
    return '<div class="row">' + lead + '<span class="main"><span class="t">' + esc(title) + '</span><span class="s">' + esc(sub) + '</span></span>' + amt +
      (deletable && r.kind !== 'oblig' ? '<button class="icon-btn" aria-label="مسح العملية" data-act="del" data-kind="' + r.kind + '" data-id="' + esc(r.id) + '">' + ic('trash', 20) + '</button>' : '') + '</div>';
  }

  function oblNote(o) {
    const t = tplOf(o.id);
    if (!t) return '';
    if (t.plan) {
      if (o.amount > 0 && o.auto) return 'قسط ' + o.planDates.map((d) => dateAr(d)).join(' + ');
      if (!(o.amount > 0)) {
        const sm = L.scheduleSummary(t.plan);
        return sm.done ? 'خلّصت كل الأقساط' : 'مفيش قسط الشهر ده · الجاي ' + dateAr(sm.next.date) + ' (' + fmt(sm.next.amount) + ' ج.م)';
      }
    }
    if (t.rates && o.auto) return 'المبلغ تلقائي من الجدول' + (o.carryOver ? ' · فيه متأخر ' + fmt(o.carryOver) : '');
    return '';
  }

  function planCard(m) {
    const t = S.settings.obligations.find((x) => x.plan);
    if (!t) return '';
    const p = t.plan, sm = L.scheduleSummary(p), today = L.todayStr();
    const ob = m.obligations.find((o) => o.id === t.id);
    const dueDates = ob ? ob.planDates : [];
    const total = sm.paidCount + sm.remainingCount;
    const left = sm.next ? L.diffDays(today, sm.next.date) : 0;
    const steps = p.items.slice().sort((x, y) => (x.date < y.date ? -1 : 1)).map((it) => {
      const cls = it.paid ? 'done' : dueDates.includes(it.date) ? 'due' : '';
      const tag = it.paid ? '<span class="chip good">اتدفع</span>' : dueDates.includes(it.date) ? '<span class="chip warn">مستحق</span>' : '<span class="chip">جاي</span>';
      return '<div class="step ' + cls + '"><span class="dot">' + (it.paid ? ic('check', 14) : '') + '</span><span><span class="t">' + dateAr(it.date, true) + '</span><span class="s" style="display:block"><span class="num">' + fmt(it.amount) + '</span> ج.م</span></span>' + tag + '</div>';
    }).join('');
    return sec(esc(t.name)) + '<div class="card"><div class="card pad" style="border:0;box-shadow:none;padding-bottom:var(--s3)">' +
      '<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px"><b>' + (sm.done ? 'خلّصت الأقساط' : sm.paidCount + ' من ' + total + ' اتدفعوا') + '</b><span class="hint">' + (sm.done ? '' : 'متبقي ' + money(sm.remainingTotal)) + '</span></div>' +
      '<div class="progress" role="progressbar" aria-valuenow="' + sm.paidCount + '" aria-valuemin="0" aria-valuemax="' + total + '"><i style="width:' + (total ? Math.round(sm.paidCount / total * 100) : 0) + '%"></i></div>' +
      (sm.done ? '<div class="warnbox good" style="margin:12px 0 0">' + ic('check-circle', 20) + '<span>خلّصت أقساط شقة الإسكان. مبروك.</span></div>' :
        '<p class="hint" style="margin-top:10px">القسط الجاي ' + dateAr(sm.next.date, true) + (left > 0 ? ' · بعد <span class="num">' + left + '</span> يوم' : '') + ' · آخر قسط ' + dateAr(sm.lastDate, true) + '</p>') +
      '<div class="divider"></div><div class="kv"><span class="hint">المقدم (اتدفع)</span><b>' + num(p.downPayment) + '</b></div>' +
      '<div class="kv"><span class="hint">القسط كل ' + p.everyMonths + ' شهور</span><b>' + p.years.map((y) => num(y.amount)).join(' ← ') + '</b></div></div>' +
      '<div class="steps" style="border-top:1px solid var(--line)">' + steps + '</div></div>';
  }

  function viewBills(m) {
    const t = L.totals(m);
    const cards = m.obligations.length ? m.obligations.map((o) => {
      const note = oblNote(o);
      const chip = o.paid ? '<span class="chip good">' + ic('check', 14) + 'اتدفع' + (o.paidDate ? ' ' + dateAr(o.paidDate) : '') + '</span>' : o.amount > 0 ? '<span class="chip warn">مستحق</span>' : '<span class="chip">مفيش الشهر ده</span>';
      return '<div class="card oblig' + (o.paid ? ' paid' : '') + '"><div class="head">' + oblTile(o.id) + '<div class="main"><div class="nm">' + esc(o.name) + '</div>' + (note ? '<div class="note">' + esc(note) + '</div>' : '') + '</div>' + chip + '</div>' +
        '<div class="ctl"><label class="money-in"><span class="sr">مبلغ ' + esc(o.name) + '</span><input inputmode="decimal" placeholder="المبلغ" data-act="amt" data-id="' + esc(o.id) + '" value="' + (o.amount > 0 ? o.amount : '') + '"' + (o.paid ? ' disabled' : '') + '><small>ج.م</small></label>' +
        '<button class="paybtn' + (o.paid ? ' done' : '') + '" data-act="pay" data-id="' + esc(o.id) + '"' + (o.amount > 0 ? '' : ' disabled') + '>' + (o.paid ? ic('check', 18) + 'دفعت' : 'دفعت') + '</button></div></div>';
    }).join('') : '<div class="card">' + empty('wallet', 'مفيش التزامات', 'ضيف التزام من "المزيد".', '<button class="btn sm" data-act="edit-oblig">إضافة التزام</button>') + '</div>';

    return pageHead('الالتزامات', 'أقساط وإيجار وجمعية') +
      '<p class="hint" style="margin:2px 4px var(--s3)">المبلغ بيتحجز من الفلوس الحرة، ولما تدفعه دوس "دفعت". الأقساط والإيجار بيتحسبوا من الجدول وتقدر تعدّل المبلغ.</p>' +
      '<div class="tiles3"><div class="stat"><div class="v">' + num(t.obligationsPlanned) + '</div><div class="k">محجوز</div></div><div class="stat"><div class="v">' + num(t.obligationsPaid) + '</div><div class="k">دفعت</div></div><div class="stat"><div class="v">' + num(t.obligationsUnpaid) + '</div><div class="k">لسه</div></div></div>' +
      '<div style="margin-top:var(--s3)">' + cards + '</div>' + planCard(m) + credit();
  }

  function viewLog(m) {
    const today = L.todayStr();
    const f = ui.histFilter;
    let list = recentEntries(m);
    if (f === 'expenses') list = list.filter((r) => r.kind === 'expenses' || r.kind === 'oblig');
    if (f === 'extras') list = list.filter((r) => r.kind === 'extras');
    const groups = [];
    list.forEach((r) => { let g = groups[groups.length - 1]; if (!g || g.date !== r.date) { g = { date: r.date, items: [] }; groups.push(g); } g.items.push(r); });
    return pageHead('السجل', 'كل اللي اتسجل الشهر ده') +
      '<div class="seg">' + [['all', 'الكل'], ['expenses', 'مصروفات'], ['extras', 'دخل إضافي']].map((x) => '<button data-act="filter" data-v="' + x[0] + '" aria-pressed="' + (f === x[0]) + '">' + x[1] + '</button>').join('') + '</div>' +
      (groups.length ? groups.map((g) => {
        const out = L.sum(g.items.filter((r) => r.kind !== 'extras').map((r) => r.amount));
        return '<div class="day"><span>' + dayLabel(g.date, today) + '</span><span>' + (out ? 'صرفت <span class="num">' + fmt(out) + '</span>' : '') + '</span></div><div class="card">' + g.items.map((r) => entryRow(r, today, true)).join('') + '</div>';
      }).join('') : '<div class="card" style="margin-top:var(--s4)">' + empty('log', 'مفيش حاجة هنا', 'العمليات هتظهر أول ما تسجّلها.', '<button class="btn sm" data-act="open-add">' + ic('plus', 20) + 'سجّل دلوقتي</button>') + '</div>') + credit();
  }

  const setRow = (act, icon, color, title, sub, extra) =>
    '<button class="row" data-act="' + act + '"' + (extra || '') + '>' + tile(ic(icon, 22), color) + '<span class="main"><span class="t">' + title + '</span>' + (sub ? '<span class="s">' + sub + '</span>' : '') + '</span><span class="chev">' + ic('chevron', 20) + '</span></button>';

  function viewMore() {
    const t = S.settings.theme;
    const closed = S.months.filter((x) => x.closed).slice().reverse();
    return pageHead('المزيد', 'الشهر والإعدادات') +
      '<div class="group"><span class="lbl">الشهر</span><div class="card">' +
      setRow('close-month', 'archive', 'var(--brand)', 'قفّل الشهر', 'ملخص، والباقي ينتقل للشهر الجديد') +
      closed.map((c) => '<button class="row" data-act="view-month" data-id="' + esc(c.id) + '">' + tile(ic('calendar', 20), 'var(--ink-3)', 'sm') + '<span class="main"><span class="t">' + dateAr(c.startDate) + ' ← ' + dateAr(c.endDate) + '</span><span class="s">اتصرف ' + fmt(c.summary.expensesTotal) + ' ج.م</span></span><span class="amt">' + num(c.summary.remaining) + '</span></button>').join('') + '</div></div>' +
      '<div class="group"><span class="lbl">المظهر</span><div class="seg">' + [['auto', 'auto', 'زي الموبايل'], ['light', 'sun', 'فاتح'], ['dark', 'moon', 'غامق']].map((x) => '<button data-act="theme" data-v="' + x[0] + '" aria-pressed="' + (t === x[0]) + '">' + ic(x[1], 18) + x[2] + '</button>').join('') + '</div></div>' +
      '<div class="group"><span class="lbl">القوائم</span><div class="card">' +
      setRow('edit-cats', 'receipt', '#E8833A', 'بنود المصروفات', S.settings.categories.length + ' بند') +
      setRow('edit-oblig', 'wallet', '#3D7EDB', 'الالتزامات الثابتة', S.settings.obligations.length + ' التزام') +
      (S.settings.obligations.some((o) => o.plan) ? setRow('edit-plan', 'building', '#6C5CE7', 'جدول أقساط الإسكان', 'التواريخ والمبالغ') : '') +
      (S.settings.obligations.some((o) => o.rates) ? setRow('edit-rates', 'key', '#0E8579', 'جدول الإيجار', 'الإيجار الشهري وتغييراته') : '') + '</div></div>' +
      '<div class="group"><span class="lbl">البيانات</span><div class="card">' +
      setRow('export', 'download', 'var(--good)', 'حفظ نسخة احتياطية', 'ملف بكل بياناتك') +
      setRow('import', 'upload', 'var(--low)', 'استرجاع نسخة', 'بيحل مكان البيانات الحالية') + '</div>' +
      '<input type="file" id="file" accept=".json,application/json" hidden>' +
      (memoryOnly ? '<div class="warnbox" style="margin-top:12px">' + ic('alert', 20) + '<span>المتصفح مش سامح بحفظ البيانات. افتح التطبيق من Chrome عادي مش من تصفح خفي.</span></div>' : '') + '</div>' +
      '<div class="card pad" style="display:flex;align-items:center;gap:12px"><span class="logo-sm">' + ic('wallet', 22) + '</span><div><b>مصروفي</b><div class="hint">الإصدار ' + VERSION + ' · شغال بدون نت</div></div></div>' + credit();
  }

  function viewSetup(first) {
    const prev = lastClosed();
    const today = L.todayStr();
    const carry = prev && prev.summary ? prev.summary.remaining : 0;
    return '<div class="welcome"><span class="logo-sm">' + ic('wallet', 34) + '</span>' +
      (first && !prev ? '<h1>أهلاً في مصروفي</h1><p class="hint">اكتب مرتبك وبداية الشهر، وابدأ سجّل.</p>' : '<h1>شهر جديد</h1><p class="hint">اكتب مرتب الشهر الجديد.</p>') + '</div>' +
      (prev && prev.summary ? '<div class="warnbox ' + (carry < 0 ? '' : 'good') + '">' + ic(carry < 0 ? 'alert' : 'check-circle', 20) + '<span>الشهر اللي فات خلص بباقي <b>' + fmt(carry) + ' ج.م</b>' + (carry < 0 ? ' (عليك)' : '') + '، وهيتحسب في الشهر الجديد.</span></div>' : '') +
      '<div class="card pad"><div class="field"><label for="f-sal">المرتب اللي قبضته</label><div class="money-in"><input id="f-sal" inputmode="decimal" placeholder="مثلاً 8500" dir="ltr"><small>ج.م</small></div></div>' +
      '<div class="two"><div class="field"><label for="f-start">يوم القبض</label><input type="date" id="f-start" value="' + today + '"></div>' +
      '<div class="field"><label for="f-next">القبض الجاي</label><input type="date" id="f-next" value="' + addDays(today, 30) + '"></div></div>' +
      (!prev ? '<div class="field" style="margin-bottom:0"><label for="f-carry">فلوس معاك من قبل (لو فيه)</label><div class="money-in"><input id="f-carry" inputmode="decimal" placeholder="0" dir="ltr"><small>ج.م</small></div></div>' : '') + '</div>' +
      '<p class="err" id="err" role="alert"></p><button class="btn" data-act="start" style="margin-top:var(--s3)">ابدأ الشهر</button>' + credit();
  }

  /* ---------- النوافذ ---------- */
  function sheetAdd() {
    const s = ui.sheet;
    const today = L.todayStr();
    const isExp = s.mode === 'expense';
    let body;
    if (isExp) {
      body = '<div class="qrail" id="qrail" role="group" aria-label="البند">' + S.settings.categories.map((c) => '<button class="qc" style="--c:' + esc(c.color) + '" data-act="pick" data-id="' + esc(c.id) + '" aria-pressed="' + (s.cat === c.id) + '">' + catTile(c) + '<span>' + esc(c.name) + '</span></button>').join('') + '</div>' +
        '<button class="morebtn" data-act="more" aria-expanded="false">' + ic('plus', 16) + 'ملاحظة أو تاريخ تاني</button>' +
        '<div class="two" id="a-more" hidden><div class="field"><label for="a-note">ملاحظة</label><input id="a-note" type="text" maxlength="60"></div><div class="field"><label for="a-date">التاريخ</label><input id="a-date" type="date" value="' + today + '"></div></div>';
    } else {
      const sources = [...new Set(S.months.flatMap((x) => x.extras.map((e) => e.source)).filter(Boolean))];
      body = '<div class="field"><label for="a-src">الفلوس جت منين؟</label><input id="a-src" type="text" maxlength="40" list="srcs" placeholder="مثلاً مكافأة، شغل جانبي، هدية"><datalist id="srcs">' + sources.map((x) => '<option value="' + esc(x) + '">').join('') + '</datalist></div>' +
        '<div class="field"><label for="a-date">التاريخ</label><input id="a-date" type="date" value="' + today + '"></div>';
    }
    const content = '<div class="seg compact"><button data-act="mode" data-v="expense" aria-pressed="' + isExp + '">' + ic('trend-down', 18) + 'مصروف</button><button data-act="mode" data-v="extra" aria-pressed="' + !isExp + '">' + ic('coins', 18) + 'دخل إضافي</button></div>' +
      '<div class="amount"><input id="a-amt" inputmode="decimal" placeholder="0" aria-label="المبلغ" dir="ltr" autocomplete="off"><span>ج.م</span></div><div class="amount-prev" id="a-prev" aria-live="polite"></div>' + body +
      '<p class="err" id="err" role="alert"></p>';
    return sheetShell(isExp ? 'مصروف جديد' : 'دخل إضافي', content, '<button class="btn" data-act="save-add">' + ic('check', 22) + (isExp ? 'سجّل المصروف' : 'ضيف على المرتب') + '</button>');
  }

  function summaryBlock(sm) {
    return '<div class="card"><ul class="ledger">' +
      '<li><span class="k">المرتب</span><span class="v">' + num(sm.salary) + '</span></li>' +
      (sm.carryIn ? '<li><span class="k">مرحّل</span><span class="v">' + num(sm.carryIn) + '</span></li>' : '') +
      (sm.extrasTotal ? '<li class="pos"><span class="k">دخل إضافي</span><span class="v">' + pos(sm.extrasTotal) + '</span></li>' : '') +
      '<li class="neg"><span class="k">اتصرف</span><span class="v">' + neg(sm.expensesTotal) + '</span></li>' +
      (sm.obligationsPaid ? '<li class="neg"><span class="k">التزامات اتدفعت</span><span class="v">' + neg(sm.obligationsPaid) + '</span></li>' : '') +
      '<li class="total"><span class="k">الباقي</span><span class="v">' + money(sm.remaining) + '</span></li></ul></div>' +
      (sm.topCategory ? '<p class="hint" style="margin:10px 4px 0">أكتر بند صرفت فيه: <b>' + esc(catOf(sm.topCategory.cat).name) + '</b> (' + fmt(sm.topCategory.total) + ' ج.م)</p>' : '');
  }

  function sheetClose(m) {
    const today = L.todayStr();
    const end = ui.sheet.end || today;
    const { summary } = L.closeMonth(m, end);
    const unpaid = m.obligations.filter((o) => o.amount > 0 && !o.paid);
    const body = summaryBlock(summary) +
      (unpaid.length ? '<div class="warnbox" style="margin-top:12px">' + ic('alert', 20) + '<span>لسه ما دفعتش: ' + unpaid.map((o) => esc(o.name) + ' (' + fmt(o.amount) + ')').join('، ') + '. هتكمل معاك في الشهر الجديد.</span></div>' : '') +
      '<div class="field" style="margin-top:12px"><label for="c-end">آخر يوم في الشهر</label><input type="date" id="c-end" value="' + end + '" data-act="end-date"></div>';
    return sheetShell('تقفيل الشهر', body, '<div class="two"><button class="btn ghost" data-act="close-sheet">رجوع</button><button class="btn" data-act="confirm-close">قفّل الشهر</button></div>');
  }

  function sheetMonth() {
    const c = S.months.find((x) => x.id === ui.sheet.id);
    if (!c) return '';
    const bc = c.summary.byCategory;
    const body = summaryBlock(c.summary) + (bc.length ? sec('اتصرف فين') + donutCard(bc, c.summary.expensesTotal) : '');
    return sheetShell(dateAr(c.startDate) + ' ← ' + dateAr(c.endDate), body, '<button class="btn ghost" data-act="close-sheet">تمام</button>');
  }

  function sheetCats() {
    const e = ui.sheet.edit;
    const rows = S.settings.categories.map((c) => {
      let r = '<div class="editrow"><button class="tile" style="--c:' + esc(c.color) + '" data-act="cat-tile" data-id="' + esc(c.id) + '" aria-label="تغيير الأيقونة واللون" aria-expanded="' + (e === c.id) + '">' + catGlyph(c) + '</button>' +
        '<input class="input" data-act="cat-name" data-id="' + esc(c.id) + '" value="' + esc(c.name) + '" aria-label="اسم البند" maxlength="30"><button class="icon-btn" data-act="cat-del" data-id="' + esc(c.id) + '" aria-label="مسح البند">' + ic('trash', 20) + '</button></div>';
      if (e === c.id) {
        r += '<div class="picker">' + IC.PICKABLE.map((k) => '<button data-act="cat-icon" data-id="' + esc(c.id) + '" data-k="' + k + '" aria-label="' + k + '" aria-pressed="' + (IC.resolve(c.icon) === k) + '">' + ic(k, 20) + '</button>').join('') + '<span class="full"></span>' +
          PALETTE.slice(0, 8).map((p) => '<button class="sw" style="background:' + p + '" data-act="cat-color" data-id="' + esc(c.id) + '" data-k="' + p + '" aria-label="لون" aria-pressed="' + (c.color === p) + '"></button>').join('') + '</div>';
      }
      return r;
    }).join('');
    return sheetShell('بنود المصروفات', '<p class="hint" style="margin-bottom:12px">دوس على الأيقونة لتغييرها أو تغيير اللون. الاسم بيتحفظ لوحده.</p>' + rows +
      '<button class="btn ghost" data-act="cat-add">' + ic('plus', 20) + 'بند جديد</button>', '<button class="btn" data-act="close-sheet">تمام</button>');
  }

  function sheetObl() {
    const rows = S.settings.obligations.map((o) => '<div class="editrow" style="grid-template-columns:44px minmax(0,1fr) 40px">' + oblTile(o.id) +
      '<input class="input" data-act="ob-name" data-id="' + esc(o.id) + '" value="' + esc(o.name) + '" aria-label="اسم الالتزام" maxlength="40"><button class="icon-btn" data-act="ob-del" data-id="' + esc(o.id) + '" aria-label="مسح الالتزام">' + ic('trash', 20) + '</button></div>').join('');
    return sheetShell('الالتزامات الثابتة', '<p class="hint" style="margin-bottom:12px">الأسماء بس هنا. المبلغ بتكتبه كل شهر من شاشة الالتزامات.</p>' + rows +
      '<button class="btn ghost" data-act="ob-add">' + ic('plus', 20) + 'التزام جديد</button>', '<button class="btn" data-act="close-sheet">تمام</button>');
  }

  function sheetPlan() {
    const t = S.settings.obligations.find((x) => x.plan);
    const items = t.plan.items.slice().sort((x, y) => (x.date < y.date ? -1 : 1));
    const rows = items.map((it) => '<div class="editrow" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr) 40px"><input class="input" type="date" data-act="pl-date" data-d="' + esc(it.date) + '" value="' + esc(it.date) + '"' + (it.paid ? ' disabled' : '') + ' aria-label="تاريخ القسط">' +
      '<input class="input" inputmode="decimal" dir="ltr" data-act="pl-amt" data-d="' + esc(it.date) + '" value="' + it.amount + '"' + (it.paid ? ' disabled' : '') + ' aria-label="مبلغ القسط">' +
      (it.paid ? '<span class="icon-btn" title="اتدفع" style="color:var(--good)">' + ic('check', 20) + '</span>' : '<button class="icon-btn" data-act="pl-del" data-d="' + esc(it.date) + '" aria-label="مسح القسط">' + ic('trash', 20) + '</button>') + '</div>').join('');
    return sheetShell('جدول أقساط الإسكان', '<p class="hint" style="margin-bottom:12px">التاريخ والمبلغ لكل قسط. القسط اللي اتدفع ما بيتعدلش.</p>' + rows +
      '<button class="btn ghost" data-act="pl-add">' + ic('plus', 20) + 'قسط جديد</button>', '<button class="btn" data-act="close-sheet">تمام</button>');
  }

  function sheetRates() {
    const t = S.settings.obligations.find((x) => x.rates);
    const rates = t.rates.slice().sort((x, y) => (x.from < y.from ? -1 : 1));
    const rows = rates.map((r) => '<div class="editrow" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr) 40px"><input class="input" type="date" data-act="rt-from" data-d="' + esc(r.from) + '" value="' + esc(r.from) + '" aria-label="من تاريخ">' +
      '<input class="input" inputmode="decimal" dir="ltr" data-act="rt-amt" data-d="' + esc(r.from) + '" value="' + r.amount + '" aria-label="الإيجار">' +
      (rates.length > 1 ? '<button class="icon-btn" data-act="rt-del" data-d="' + esc(r.from) + '" aria-label="مسح">' + ic('trash', 20) + '</button>' : '<span></span>') + '</div>').join('');
    return sheetShell('جدول الإيجار', '<p class="hint" style="margin-bottom:12px">كل سطر معناه: من التاريخ ده، الإيجار الشهري بقى كذا.</p>' + rows +
      '<button class="btn ghost" data-act="rt-add">' + ic('plus', 20) + 'تغيير جديد في الإيجار</button>', '<button class="btn" data-act="close-sheet">تمام</button>');
  }

  /* ---------- الرسم ---------- */
  let lastSheetKey = '', lastScroll = 0;
  function paintSheet() {
    layers();
    const sh = ui.sheet;
    const host = $('#sheetLayer');
    if (!sh) { host.innerHTML = ''; lastSheetKey = ''; return; }
    const body0 = $('.sh-body', host);
    if (body0 && lastSheetKey === sh.type) lastScroll = body0.scrollTop; else lastScroll = 0;
    let inner = '';
    const m = openMonth();
    if (sh.type === 'add') inner = sheetAdd();
    else if (sh.type === 'close' && m) inner = sheetClose(m);
    else if (sh.type === 'month') inner = sheetMonth();
    else if (sh.type === 'cats') inner = sheetCats();
    else if (sh.type === 'oblig') inner = sheetObl();
    else if (sh.type === 'plan') inner = sheetPlan();
    else if (sh.type === 'rates') inner = sheetRates();
    const fresh = lastSheetKey !== sh.type;
    host.innerHTML = '<div class="scrim" data-act="scrim"><div class="sheet" role="dialog" aria-modal="true"' + (fresh ? '' : ' style="animation:none"') + '>' + inner + '</div></div>';
    lastSheetKey = sh.type;
    const body = $('.sh-body', host);
    if (body && lastScroll) body.scrollTop = lastScroll;
    if (sh.type === 'add') { const on = document.querySelector('#qrail .qc[aria-pressed="true"]'); if (on && on.scrollIntoView) on.scrollIntoView({ inline: 'center', block: 'nearest' }); }
    if (sh.type === 'add' && !sh.noFocus) { const a = $('#a-amt'); if (a) { a.value = sh.amt || ''; a.focus(); previewAmt(); } }
  }

  function navTab(id, label) { return '<button class="tab" data-act="tab" data-v="' + id + '"' + (ui.tab === id ? ' aria-current="page"' : '') + '>' + ic(id, 24) + '<span>' + label + '</span></button>'; }
  const navHtml = () => '<nav class="bar" aria-label="التنقل"><div class="in">' + navTab('home', 'الرئيسية') + navTab('bills', 'الالتزامات') +
    '<button class="fab" data-act="open-add" aria-label="تسجيل جديد">' + ic('plus', 30) + '</button>' + navTab('log', 'السجل') + navTab('more', 'المزيد') + '</div></nav>';

  let splashDone = false;
  function finishSplash() {
    if (splashDone) return;
    splashDone = true;
    const s = $('#splash');
    if (!s) return;
    setTimeout(() => { s.classList.add('hide'); setTimeout(() => s.remove(), 450); }, 380);
  }

  function render() {
    applyTheme();
    const app = $('#app');
    const m = openMonth();
    if (!m) {
      app.className = 'setup';
      app.innerHTML = '<main class="screen enter">' + viewSetup(S.months.length === 0) + '</main>';
      paintSheet(); paintDialog(); paintToast(); finishSplash();
      return;
    }
    app.className = '';
    const view = { home: viewHome, bills: viewBills, log: viewLog, more: viewMore }[ui.tab];
    app.innerHTML = '<main class="screen' + (ui.enter ? ' enter' : '') + '">' + view(m) + '</main>' + navHtml();
    ui.enter = false;
    paintSheet(); paintDialog(); paintToast();
    if (ui.tab === 'home' && ui.animate && !reduceMotion) {
      const big = $('.hero2 .bn');
      if (big) countUp(big, Number(big.dataset.v));
    }
    ui.animate = false;
    finishSplash();
  }

  /* ---------- زر الرجوع (أندرويد) ---------- */
  function openSheet(sh) {
    ui.sheet = sh; paintSheet();
    try { history.pushState({ s: 1 }, ''); } catch (e) { /* مش مهم */ }
  }
  function closeSheet(fromPop) {
    if (!ui.sheet) return;
    ui.sheet = null; paintSheet();
    if (!fromPop) { try { if (history.state && history.state.s) { ignorePop = true; history.back(); } } catch (e) { ignorePop = false; } }
  }
  let ignorePop = false; // الرجوع اللي بنعمله إحنا بعد قفل النافذة مش رجوع من المستخدم
  window.addEventListener('popstate', () => {
    if (ignorePop) { ignorePop = false; return; }
    if (ui.dialog) { closeDialog(false); return; }
    if (ui.sheet) { closeSheet(true); return; }
    if (ui.tab !== 'home') { ui.tab = 'home'; ui.animate = true; ui.enter = true; render(); }
  });

  /* ---------- الأحداث ---------- */
  function setErr(msg) {
    const e = $('#err');
    if (e) e.innerHTML = msg ? ic('alert', 18) + '<span>' + esc(msg) + '</span>' : '';
  }
  function previewAmt() {
    const p = $('#a-prev'), a = $('#a-amt');
    if (!p || !a) return;
    const v = parseAmt(a.value);
    p.innerHTML = v > 0 ? '<span class="num">' + fmt(v) + '</span> جنيه' : '';
  }
  function download(name, text) {
    if (window.MasroufiAndroid && window.MasroufiAndroid.saveBackup) { window.MasroufiAndroid.saveBackup(name, text); return; }
    const blob = new Blob([text], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }
  function refreshAuto() {
    const i = S.months.findIndex((m) => !m.closed);
    if (i >= 0) S.months[i] = L.applySchedules(S.months[i], S.settings.obligations);
    save();
  }
  function syncOpen() {
    const i = S.months.findIndex((m) => !m.closed);
    if (i >= 0) S.months[i] = L.syncObligations(S.months[i], S.settings.obligations);
  }

  const actions = {
    tab(el) {
      const to = el.dataset.v;
      if (to !== ui.tab) {
        ui.tab = to; ui.animate = to === 'home'; ui.enter = true;
        try { if (to !== 'home') { if (history.state && history.state.t) history.replaceState({ t: 1 }, ''); else history.pushState({ t: 1 }, ''); } } catch (e) { /* مش مهم */ }
        render(); window.scrollTo(0, 0);
      }
    },
    filter(el) { ui.histFilter = el.dataset.v; render(); },
    'open-add'(el) {
      const m = openMonth();
      const ids = S.settings.categories.map((c) => c.id);
      const last = m && m.expenses.length ? m.expenses[m.expenses.length - 1].cat : null;
      const want = (el && el.dataset && el.dataset.cat) || last;
      openSheet({ type: 'add', mode: 'expense', cat: ids.includes(want) ? want : ids[0] });
    },
    more(el) {
      const d = document.getElementById('a-more'); if (!d) return;
      d.hidden = !d.hidden; el.setAttribute('aria-expanded', String(!d.hidden));
      if (!d.hidden) { const n = document.getElementById('a-note'); if (n) n.focus(); }
    },
    mode(el) { ui.sheet.amt = val('a-amt'); ui.sheet.mode = el.dataset.v; paintSheet(); },
    pick(el) {
      ui.sheet.cat = el.dataset.id;
      document.querySelectorAll('.qc').forEach((b) => b.setAttribute('aria-pressed', String(b === el)));
      const a = document.getElementById('a-amt'); if (a) a.focus();
    },
    'save-add'() {
      const amt = parseAmt(val('a-amt'));
      if (!(amt > 0)) { setErr('اكتب المبلغ الأول'); const a = $('#a-amt'); if (a) a.focus(); return; }
      const date = val('a-date') || L.todayStr();
      try {
        if (ui.sheet.mode === 'expense') {
          if (!ui.sheet.cat) return setErr('اختار البند');
          const note = val('a-note').trim();
          const cat = ui.sheet.cat;
          ui.animate = true;
          closeSheet();
          mutate((m) => L.addExpense(m, { date, amount: amt, cat, note }), 'اتسجل ' + fmt(amt) + ' ج.م · ' + catOf(cat).name);
        } else {
          const source = val('a-src').trim();
          if (!source) { setErr('اكتب الفلوس جت منين'); return; }
          ui.animate = true;
          closeSheet();
          mutate((m) => L.addExtra(m, { date, amount: amt, source }), 'اتضاف ' + fmt(amt) + ' على المرتب · ' + source);
        }
        buzz();
      } catch (e) { setErr(e.message); }
    },
    del(el) { const kind = el.dataset.kind, id = el.dataset.id; mutate((m) => L.removeEntry(m, kind, id), 'اتمسحت العملية'); },
    pay(el) {
      const id = el.dataset.id;
      const o = openMonth().obligations.find((x) => x.id === id);
      const prev = JSON.stringify(S);
      S = L.payWithPlan(S, id, !o.paid, L.todayStr());
      save(); render(); buzz();
      toast(o.paid ? 'اتلغى الدفع' : 'اتسجل إنك دفعت ' + o.name, { undo: () => { S = JSON.parse(prev); save(); render(); } });
    },
    theme(el) { S.settings.theme = el.dataset.v; save(); render(); },
    'close-month'() { openSheet({ type: 'close', end: L.todayStr() }); },
    'end-date'(el) { ui.sheet.end = el.value || L.todayStr(); paintSheet(); },
    'confirm-close'() {
      const m = openMonth();
      const end = ui.sheet.end || L.todayStr();
      if (end < m.startDate) { setErr(''); toast('آخر يوم لازم يكون بعد يوم القبض', { kind: 'error' }); return; }
      const { closed } = L.closeMonth(m, end);
      S.months[S.months.indexOf(m)] = closed;
      save(); closeSheet(); ui.tab = 'home'; ui.enter = true; render(); buzz();
    },
    'view-month'(el) { openSheet({ type: 'month', id: el.dataset.id }); },
    start() {
      const sal = parseAmt(val('f-sal'));
      const start = val('f-start'), next = val('f-next');
      if (!(sal > 0)) return setErr('اكتب المرتب');
      if (!start) return setErr('اختار يوم القبض');
      if (next && next <= start) return setErr('القبض الجاي لازم يكون بعد يوم القبض');
      const id = L.uid();
      const prev = lastClosed();
      let m;
      if (prev && prev.summary && !S.months.some((x) => !x.closed)) {
        m = L.startNextMonth(prev, { id, salary: sal, startDate: start, nextPayday: next || null });
        m = L.syncObligations(m, S.settings.obligations);
      } else {
        const cv = $('#f-carry') ? parseAmt(val('f-carry') || '0') : 0;
        if (isNaN(cv)) return setErr('الرصيد القديم مش رقم صحيح');
        m = L.newMonth({ id, startDate: start, nextPayday: next || null, salary: sal, carry: cv, obligationNames: S.settings.obligations });
      }
      m = L.applySchedules(m, S.settings.obligations);
      S.months.push(m); save(); ui.tab = 'home'; ui.animate = true; ui.enter = true; render(); buzz();
    },
    'edit-cats'() { openSheet({ type: 'cats', edit: null }); },
    'edit-oblig'() { openSheet({ type: 'oblig' }); },
    'edit-plan'() { openSheet({ type: 'plan' }); },
    'edit-rates'() { openSheet({ type: 'rates' }); },
    'cat-tile'(el) { ui.sheet.edit = ui.sheet.edit === el.dataset.id ? null : el.dataset.id; paintSheet(); },
    'cat-icon'(el) { const c = S.settings.categories.find((x) => x.id === el.dataset.id); if (c) { c.icon = el.dataset.k; save(); paintSheet(); } },
    'cat-color'(el) { const c = S.settings.categories.find((x) => x.id === el.dataset.id); if (c) { c.color = el.dataset.k; save(); paintSheet(); } },
    'cat-add'() {
      const used = S.settings.categories.length;
      const c = { id: 'c' + L.uid(), name: 'بند جديد', icon: 'receipt', color: PALETTE[used % PALETTE.length] };
      S.settings.categories.push(c);
      ui.sheet.edit = c.id; save(); paintSheet();
    },
    async 'cat-del'(el) {
      const c = catOf(el.dataset.id);
      const ok = await confirmDlg({ icon: 'trash', danger: true, title: 'مسح البند "' + c.name + '"؟', text: 'العمليات القديمة هتفضل موجودة بس هتظهر باسم "بند محذوف".', ok: 'امسح' });
      if (!ok) return;
      S.settings.categories = S.settings.categories.filter((x) => x.id !== el.dataset.id);
      if (ui.sheet && ui.sheet.edit === el.dataset.id) ui.sheet.edit = null;
      save(); paintSheet();
    },
    'ob-add'() {
      S.settings.obligations.push({ id: 'o' + L.uid(), name: 'التزام جديد' });
      syncOpen(); save(); paintSheet();
    },
    async 'ob-del'(el) {
      const t = tplOf(el.dataset.id);
      const ok = await confirmDlg({ icon: 'trash', danger: true, title: 'مسح "' + (t ? t.name : '') + '"؟', text: 'هيتشال من قايمة الالتزامات. اللي عليه مبلغ الشهر ده هيفضل لحد ما الشهر يخلص.', ok: 'امسح' });
      if (!ok) return;
      S.settings.obligations = S.settings.obligations.filter((o) => o.id !== el.dataset.id);
      const i = S.months.findIndex((m) => !m.closed);
      if (i >= 0) {
        const mm = JSON.parse(JSON.stringify(S.months[i]));
        mm.obligations = mm.obligations.filter((o) => o.id !== el.dataset.id || o.amount > 0);
        S.months[i] = mm;
      }
      save(); paintSheet();
    },
    'pl-add'() {
      const t = S.settings.obligations.find((x) => x.plan);
      const last = t.plan.items.slice().sort((x, y) => (x.date < y.date ? -1 : 1)).pop();
      let d = last ? last.date : L.todayStr();
      const [y, mo, dd] = d.split('-').map(Number);
      d = L.todayStr(new Date(y, mo - 1 + t.plan.everyMonths, dd));
      t.plan.items.push({ date: d, amount: last ? last.amount : 0, paid: false, paidDate: null });
      refreshAuto(); paintSheet();
    },
    async 'pl-del'(el) {
      const ok = await confirmDlg({ icon: 'trash', danger: true, title: 'مسح القسط ده؟', text: 'هيتشال من الجدول.', ok: 'امسح' });
      if (!ok) return;
      const t = S.settings.obligations.find((x) => x.plan);
      t.plan.items = t.plan.items.filter((i) => i.date !== el.dataset.d);
      refreshAuto(); paintSheet();
    },
    'rt-add'() {
      const t = S.settings.obligations.find((x) => x.rates);
      const last = t.rates.slice().sort((x, y) => (x.from < y.from ? -1 : 1)).pop();
      t.rates.push({ from: L.todayStr(), amount: last ? last.amount : 0 });
      refreshAuto(); paintSheet();
    },
    async 'rt-del'(el) {
      const t = S.settings.obligations.find((x) => x.rates);
      if (t.rates.length < 2) return;
      const ok = await confirmDlg({ icon: 'trash', danger: true, title: 'مسح التغيير ده؟', text: 'الإيجار هيرجع للمبلغ اللي قبله.', ok: 'امسح' });
      if (!ok) return;
      t.rates = t.rates.filter((r) => r.from !== el.dataset.d);
      refreshAuto(); paintSheet();
    },
    export() {
      download('masroufi-backup-' + L.todayStr() + '.json', L.exportBackup(S));
      toast('اتحفظت نسخة احتياطية');
    },
    import() { const f = $('#file'); if (f) f.click(); },
    async 'confirm-import'(el, e, data) {
      S = data; S.settings = Object.assign(L.defaultSettings(), S.settings);
      save(); ui.tab = 'home'; ui.animate = true; ui.enter = true; render(); toast('اتسترجعت النسخة');
    },
    undo() { const u = ui.toast && ui.toast.undo; ui.toast = null; paintToast(); if (u) u(); },
    'close-sheet'() { closeSheet(); },
    scrim(el, e) { if (e.target === el) closeSheet(); },
    'dlg-yes'() { closeDialog(true); },
    'dlg-no'() { closeDialog(false); },
    'dlg-scrim'(el, e) { if (e.target === el) closeDialog(false); }
  };

  // حماية من الضغط المتكرر على العمليات اللي بتغيّر البيانات
  const GUARDED = new Set(['save-add', 'start', 'confirm-close', 'pay', 'confirm-import', 'export']);
  const lockUntil = {};
  const INPUT_ACTS = ['amt', 'cat-name', 'ob-name', 'end-date', 'pl-date', 'pl-amt', 'rt-from', 'rt-amt'];

  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const a = el.dataset.act;
    if (INPUT_ACTS.includes(a) || !actions[a]) return;
    if (GUARDED.has(a)) {
      const now = performance.now();
      if (now < (lockUntil[a] || 0)) return;
      lockUntil[a] = now + 700;
    }
    actions[a](el, e);
  });

  document.addEventListener('input', (e) => { if (e.target && e.target.id === 'a-amt') previewAmt(); });

  document.addEventListener('change', (e) => {
    const el = e.target;
    const a = el.dataset && el.dataset.act;
    if (a === 'amt') {
      const raw = el.value.trim();
      const v = raw === '' ? null : parseAmt(raw);
      if (v !== null && !(v > 0)) { toast('اكتب مبلغ صحيح', { kind: 'error' }); render(); return; }
      try { mutate((m) => L.setObligationAmount(m, el.dataset.id, v)); } catch (err) { toast(err.message, { kind: 'error' }); render(); }
    } else if (a === 'cat-name') {
      const c = S.settings.categories.find((x) => x.id === el.dataset.id);
      if (c) { c.name = el.value.trim() || c.name; save(); }
    } else if (a === 'ob-name') {
      const o = S.settings.obligations.find((x) => x.id === el.dataset.id);
      if (o) { o.name = el.value.trim() || o.name; syncOpen(); save(); }
    } else if (a === 'end-date') {
      actions['end-date'](el);
    } else if (a === 'pl-date' || a === 'pl-amt') {
      const t = S.settings.obligations.find((x) => x.plan);
      const it = t.plan.items.find((x) => x.date === el.dataset.d);
      if (it) {
        if (a === 'pl-date') { if (el.value && !t.plan.items.some((x) => x.date === el.value)) it.date = el.value; }
        else { const v = parseAmt(el.value); if (v > 0) it.amount = v; else toast('اكتب مبلغ صحيح', { kind: 'error' }); }
        refreshAuto(); paintSheet();
      }
    } else if (a === 'rt-from' || a === 'rt-amt') {
      const t = S.settings.obligations.find((x) => x.rates);
      const r = t.rates.find((x) => x.from === el.dataset.d);
      if (r) {
        if (a === 'rt-from') { if (el.value && !t.rates.some((x) => x.from === el.value)) r.from = el.value; }
        else { const v = parseAmt(el.value); if (v > 0) r.amount = v; else toast('اكتب مبلغ صحيح', { kind: 'error' }); }
        refreshAuto(); paintSheet();
      }
    } else if (el.id === 'file' && el.files && el.files[0]) {
      const r = new FileReader();
      r.onload = async () => {
        let data;
        try { data = L.importBackup(String(r.result)); } catch (err) { toast(err.message, { kind: 'error' }); return; }
        const ok = await confirmDlg({ icon: 'upload', danger: true, title: 'استرجاع النسخة؟', text: 'النسخة فيها ' + data.months.length + ' شهر، وهتحل مكان كل البيانات الحالية على الموبايل.', ok: 'استرجع' });
        if (ok) actions['confirm-import'](null, null, data);
      };
      r.onerror = () => toast('ما قدرتش أقرا الملف', { kind: 'error' });
      r.readAsText(el.files[0]);
      el.value = '';
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { if (ui.dialog) closeDialog(false); else if (ui.sheet) closeSheet(); }
    if (e.key === 'Enter' && ui.sheet && ui.sheet.type === 'add' && e.target.tagName === 'INPUT' && !ui.dialog) actions['save-add']();
  });

  let lastDay = L.todayStr();
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && L.todayStr() !== lastDay) { lastDay = L.todayStr(); if (!ui.sheet && !ui.dialog) render(); }
  });
  window.addEventListener('error', () => { /* ما نسيبش التطبيق معلّق على شاشة البداية */ finishSplash(); });
  try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) { /* مش مهم */ }
  if ('serviceWorker' in navigator && /^https?:/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});

  window.__masroufi = { get state() { return S; } };
  render();
})();
