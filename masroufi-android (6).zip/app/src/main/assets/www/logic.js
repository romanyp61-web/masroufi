/*
 * مصروفي — منطق الحساب (بدون واجهة، يتختبر لوحده)
 * تنفيذ وتطوير Romany fawzy
 *
 * القواعد:
 *  - الشهر يبدأ من يوم القبض، ويتقفل بإيدك.
 *  - المتاح = المرتب + المرحّل من الشهر اللي فات + أي دخل إضافي.
 *  - المتبقي = المتاح − المصروفات − الالتزامات اللي اتدفعت.
 *  - الحر للصرف = المتاح − المصروفات − كل الالتزامات المحجوزة (اتدفعت أو لسه).

 *  - الشاشة الرئيسية بتعرض: الباقي من إجمالي الفلوس (overview).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Masroufi = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------- فلوس ---------- */
  const cents = (n) => Math.round(Number(n) * 100);
  const sum = (arr) => arr.reduce((a, n) => a + cents(n), 0) / 100;
  const round2 = (n) => Math.round(n * 100) / 100;

  /* ---------- تواريخ (بتوقيت الموبايل) ---------- */
  const pad = (n) => String(n).padStart(2, '0');
  const todayStr = (d = new Date()) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const utcDay = (s) => {
    const [y, m, d] = s.split('-').map(Number);
    return Date.UTC(y, m - 1, d);
  };
  const diffDays = (a, b) => Math.round((utcDay(b) - utcDay(a)) / 86400000);

  let counter = 0;
  const uid = () => Date.now().toString(36) + (counter++).toString(36) + Math.random().toString(36).slice(2, 6);

  const clone = (x) => JSON.parse(JSON.stringify(x));

  function assertOpen(m) {
    if (m.closed) throw new Error('الشهر ده متقفل');
  }
  function assertAmount(n) {
    if (typeof n !== 'number' || !isFinite(n) || n <= 0) throw new Error('المبلغ لازم يكون أكبر من صفر');
  }

  /* ---------- الإعدادات الافتراضية ---------- */
  function defaultSettings() {
    return {
      theme: 'auto',
      categories: [
        { id: 'food', name: 'أكل', icon: '🍽️', color: '#E8833A' },
        { id: 'drink', name: 'شرب', icon: '🥤', color: '#2FA6D6' },
        { id: 'medical', name: 'علاج', icon: '💊', color: '#D6453D' },
        { id: 'gas1', name: 'غاز شقة 1', icon: '🔥', color: '#F0A500' },
        { id: 'gas2', name: 'غاز شقة 2', icon: '🔥', color: '#C98A00' },
        { id: 'elec1', name: 'كهربا شقة 1', icon: '⚡', color: '#6C5CE7' },
        { id: 'elec2', name: 'كهربا شقة 2', icon: '⚡', color: '#4B3FC4' },
        { id: 'transport', name: 'مواصلات', icon: '🚌', color: '#14877D' },
        { id: 'mobile', name: 'موبايل وإنترنت', icon: '📱', color: '#3D7EDB' },
        { id: 'clothes', name: 'ملابس', icon: '👕', color: '#C2549A' },
        { id: 'church', name: 'كنيسة وعطاء', icon: '⛪', color: '#8A6D3B' },
        { id: 'other', name: 'أخرى', icon: '🧾', color: '#7B8794' }
      ],
      obligations: [
        {
          id: 'o_housing', name: 'قسط شقة الإسكان',
          // قسط كل 3 شهور: السنة 1 كانت 7000، السنة 2 بـ 8000، السنة 3 بـ 9000، وقبلها مقدم 30000
          plan: {
            everyMonths: 3,
            downPayment: 30000,
            years: [{ year: 1, amount: 7000 }, { year: 2, amount: 8000 }, { year: 3, amount: 9000 }],
            items: [
              ['2027-01-01', 8000], ['2027-04-01', 8000],
              ['2027-07-01', 9000], ['2027-10-01', 9000], ['2028-01-01', 9000], ['2028-04-01', 9000]
            ].map((x) => ({ date: x[0], amount: x[1], paid: false, paidDate: null }))
          }
        },
        // إيجار شقة 2: 1000 لحد شهر 7/2027، وبعده 1400 كل شهر (الإيجار بيستحق أول الشهر)
        { id: 'o_rent', name: 'إيجار الشقة (شقة 2)', rates: [{ from: '2000-01-01', amount: 1000 }, { from: '2027-08-01', amount: 1400 }] },
        { id: 'o_gam3iya', name: 'الجمعية' }
      ]
    };
  }

  function emptyState() {
    return { version: 1, settings: defaultSettings(), months: [] };
  }

  /* ---------- الشهر ---------- */
  function makeObligation(t) {
    return { id: t.id, name: t.name, amount: null, paid: false, paidDate: null, auto: false, kind: null, planDates: [], carryOver: 0 };
  }

  function newMonth(o) {
    return {
      id: o.id || uid(),
      startDate: o.startDate,
      nextPayday: o.nextPayday || null,
      salary: o.salary,
      carry: o.carry || 0,
      extras: [],
      expenses: [],
      obligations: (o.obligationNames || []).map(makeObligation),
      closed: false,
      endDate: null,
      summary: null
    };
  }

  function totals(m) {
    const extrasTotal = sum(m.extras.map((e) => e.amount));
    const expensesTotal = sum(m.expenses.map((e) => e.amount));
    const withAmount = m.obligations.filter((o) => o.amount > 0);
    const obligationsPlanned = sum(withAmount.map((o) => o.amount));
    const obligationsPaid = sum(withAmount.filter((o) => o.paid).map((o) => o.amount));
    const available = sum([m.salary, m.carry, extrasTotal]);
    return {
      salary: m.salary,
      carry: m.carry,
      extrasTotal,
      available,
      expensesTotal,
      obligationsPlanned,
      obligationsPaid,
      obligationsUnpaid: round2(obligationsPlanned - obligationsPaid),
      remaining: round2(available - expensesTotal - obligationsPaid),
      free: round2(available - expensesTotal - obligationsPlanned)
    };
  }

  function addExpense(m, e) {
    assertOpen(m);
    assertAmount(e.amount);
    if (!e.cat) throw new Error('اختار البند');
    const n = clone(m);
    n.expenses.push({ id: uid(), date: e.date, amount: round2(e.amount), cat: e.cat, note: e.note || '' });
    return n;
  }

  function addExtra(m, e) {
    assertOpen(m);
    assertAmount(e.amount);
    const n = clone(m);
    n.extras.push({ id: uid(), date: e.date, amount: round2(e.amount), source: (e.source || '').trim() });
    return n;
  }

  function removeEntry(m, list, id) {
    assertOpen(m);
    if (list !== 'expenses' && list !== 'extras') throw new Error('قايمة غلط');
    const n = clone(m);
    n[list] = n[list].filter((x) => x.id !== id);
    return n;
  }

  function setObligationAmount(m, id, amount) {
    assertOpen(m);
    const n = clone(m);
    const o = n.obligations.find((x) => x.id === id);
    if (!o) throw new Error('الالتزام مش موجود');
    if (o.paid) throw new Error('الغي الدفع الأول وبعدين عدّل المبلغ');
    o.auto = false;
    if (amount === null || amount === '' || amount === 0 || amount === undefined) {
      o.amount = null;
      o.paidDate = null;
    } else {
      assertAmount(amount);
      o.amount = round2(amount);
    }
    return n;
  }

  function setObligationPaid(m, id, paid, date) {
    assertOpen(m);
    const n = clone(m);
    const o = n.obligations.find((x) => x.id === id);
    if (!o) throw new Error('الالتزام مش موجود');
    if (!(o.amount > 0)) {
      o.paid = false;
      o.paidDate = null;
      return n;
    }
    o.paid = !!paid;
    o.paidDate = paid ? date || null : null;
    return n;
  }

  /* يدمج قايمة الالتزامات في الإعدادات مع اللي في الشهر */
  function syncObligations(m, templates) {
    const n = clone(m);
    const existing = new Map(n.obligations.map((o) => [o.id, o]));
    const next = templates.map((t) => {
      const cur = existing.get(t.id);
      return cur ? Object.assign(cur, { name: t.name }) : makeObligation(t);
    });
    // التزام اتشال من الإعدادات بس عليه مبلغ لسه شغال: يفضل لحد ما الشهر يخلص
    for (const o of n.obligations) {
      if (!templates.some((t) => t.id === o.id) && o.amount > 0) next.push(o);
    }
    n.obligations = next;
    return n;
  }

  /* ---------- جداول الأقساط والإيجار ---------- */
  const addDaysStr = (s, n) => {
    const [y, m, d] = s.split('-').map(Number);
    return todayStr(new Date(y, m - 1, d + n));
  };
  const cycleEnd = (m) => m.nextPayday || addDaysStr(m.startDate, 30);

  // الإيجار بيستحق أول الشهر: الدورة اللي بتبدأ يوم 25 بتغطي أول الشهر الجاي
  function cycleRefDate(m) {
    const [y, mo, d] = m.startDate.split('-').map(Number);
    let ref = d === 1 ? m.startDate : todayStr(new Date(y, mo, 1));
    if (m.nextPayday && ref >= m.nextPayday) ref = m.startDate;
    return ref;
  }
  function rateFor(rates, ref) {
    let a = 0;
    for (const r of rates.slice().sort((x, y) => (x.from < y.from ? -1 : 1))) if (r.from <= ref) a = r.amount;
    return a;
  }

  // الأقساط اللي لسه ما اتدفعتش وميعادها قبل القبض الجاي (المتأخر بيفضل مستحق)
  function scheduleDue(plan, windowEnd) {
    const items = plan.items.filter((i) => !i.paid && i.date < windowEnd).sort((a, b) => (a.date < b.date ? -1 : 1));
    return { items, total: sum(items.map((i) => i.amount)) };
  }

  function scheduleSummary(plan) {
    const items = plan.items.slice().sort((a, b) => (a.date < b.date ? -1 : 1));
    const unpaid = items.filter((i) => !i.paid);
    return {
      total: sum(items.map((i) => i.amount)),
      paidCount: items.length - unpaid.length,
      remainingCount: unpaid.length,
      remainingTotal: sum(unpaid.map((i) => i.amount)),
      next: unpaid[0] || null,
      done: unpaid.length === 0,
      lastDate: items.length ? items[items.length - 1].date : null
    };
  }

  /* بيحسب مبلغ الالتزامات اللي ليها جدول (قسط/إيجار بيتغير) للشهر ده.
     المبلغ اللي كتبته بإيدك أو اللي اتدفع ما بيتلمسش. */
  function applySchedules(m, templates) {
    const n = clone(m);
    for (const o of n.obligations) {
      const t = templates.find((x) => x.id === o.id);
      if (!t || o.paid) continue;
      if (o.amount > 0 && o.auto === false) continue;
      if (t.plan) {
        const due = scheduleDue(t.plan, cycleEnd(n));
        o.kind = 'plan';
        o.amount = due.total > 0 ? due.total : null;
        o.planDates = due.items.map((i) => i.date);
      } else if (t.rates) {
        const a = rateFor(t.rates, cycleRefDate(n)) + (o.carryOver || 0);
        o.kind = 'rates';
        o.amount = a > 0 ? round2(a) : null;
      } else continue;
      o.auto = o.amount !== null;
    }
    return n;
  }

  /* الدفع على مستوى التطبيق كله: بيعلّم القسط في الجدول كمان */
  function payWithPlan(state, id, paid, date) {
    const s = clone(state);
    const i = s.months.findIndex((m) => !m.closed);
    if (i < 0) throw new Error('مفيش شهر مفتوح');
    s.months[i] = setObligationPaid(s.months[i], id, paid, date);
    const ob = s.months[i].obligations.find((o) => o.id === id);
    const t = s.settings.obligations.find((x) => x.id === id);
    if (t && t.plan) {
      for (const it of t.plan.items) {
        if (ob.planDates.includes(it.date)) {
          it.paid = !!ob.paid;
          it.paidDate = ob.paid ? date : null;
        }
      }
    }
    return s;
  }

  /* ---------- الحد اليومي ---------- */
  function daysLeft(m, today) {
    const d = m.nextPayday ? diffDays(today, m.nextPayday) : 30 - diffDays(m.startDate, today);
    return Math.max(1, d);
  }

  /* الباقي من إجمالي الفلوس: ده اللي بيظهر في الشاشة الرئيسية */
  function overview(m) {
    const t = totals(m);
    const ratio = t.available > 0 ? Math.max(0, Math.min(1, t.remaining / t.available)) : 0;
    let st;
    if (t.remaining < 0) st = 'over';
    else if (ratio > 0.5) st = 'good';
    else if (ratio > 0.2) st = 'warn';
    else st = 'low';
    return {
      available: t.available,
      remaining: t.remaining,
      spent: round2(t.expensesTotal + t.obligationsPaid),
      unpaid: t.obligationsUnpaid,
      free: t.free,
      ratio,
      status: st
    };
  }

  function byCategory(m) {
    const map = new Map();
    for (const e of m.expenses) map.set(e.cat, (map.get(e.cat) || 0) + cents(e.amount));
    return [...map.entries()]
      .map(([cat, c]) => ({ cat, total: c / 100 }))
      .sort((a, b) => b.total - a.total);
  }

  /* ---------- تقفيل الشهر ---------- */
  function closeMonth(m, endDate) {
    assertOpen(m);
    const t = totals(m);
    const cats = byCategory(m);
    const summary = {
      startDate: m.startDate,
      endDate,
      salary: t.salary,
      carryIn: t.carry,
      extrasTotal: t.extrasTotal,
      available: t.available,
      expensesTotal: t.expensesTotal,
      obligationsPaid: t.obligationsPaid,
      obligationsUnpaid: t.obligationsUnpaid,
      remaining: t.remaining,
      byCategory: cats,
      topCategory: cats.length ? cats[0] : null
    };
    const closed = clone(m);
    closed.closed = true;
    closed.endDate = endDate;
    closed.summary = summary;
    return { closed, summary };
  }

  function startNextMonth(prev, o) {
    if (!prev.closed || !prev.summary) throw new Error('اقفل الشهر الأول');
    const n = newMonth({
      id: o.id,
      startDate: o.startDate,
      nextPayday: o.nextPayday,
      salary: o.salary,
      carry: prev.summary.remaining,
      obligationNames: prev.obligations.map((x) => ({ id: x.id, name: x.name }))
    });
    // اللي لسه ما اتدفعش بيكمل معاك بنفس المبلغ
    n.obligations = n.obligations.map((ob) => {
      const old = prev.obligations.find((x) => x.id === ob.id);
      if (old && old.amount > 0 && !old.paid) {
        if (old.kind === 'plan') ob.kind = 'plan'; // الأقساط المتأخرة بتتحسب من الجدول نفسه
        else if (old.kind === 'rates') { ob.kind = 'rates'; ob.carryOver = old.amount; } // الإيجار المتأخر بيتضاف على إيجار الشهر الجديد
        else ob.amount = old.amount;
      } else if (old && old.kind) ob.kind = old.kind;
      return ob;
    });
    return n;
  }

  /* ---------- نسخة احتياطية ---------- */
  function exportBackup(state) {
    return JSON.stringify({ app: 'masroufi', credit: 'تنفيذ وتطوير Romany fawzy', exportedAt: new Date().toISOString(), data: state });
  }
  function importBackup(text) {
    let obj;
    try {
      obj = JSON.parse(text);
    } catch (e) {
      throw new Error('الملف مش نسخة احتياطية صحيحة');
    }
    const d = obj && obj.data;
    if (!obj || obj.app !== 'masroufi' || !d || !Array.isArray(d.months) || typeof d.settings !== 'object') {
      throw new Error('الملف مش نسخة احتياطية من مصروفي');
    }
    return d;
  }

  return {
    sum, round2, todayStr, diffDays, uid,
    defaultSettings, emptyState, newMonth, totals,
    addExpense, addExtra, removeEntry, setObligationAmount, setObligationPaid, syncObligations,
    scheduleDue, scheduleSummary, applySchedules, payWithPlan, cycleRefDate, rateFor, addDaysStr,
    daysLeft, overview, byCategory,
    closeMonth, startNextMonth, exportBackup, importBackup
  };
});
