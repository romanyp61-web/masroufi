/*
 * مصروفي — مكتبة الأيقونات الموحدة (شبكة 24، خط 1.75، أطراف مستديرة)
 * تنفيذ وتطوير Romany fawzy
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MIcons = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const P = {
    // التنقل
    home: '<path d="M4 10.5 12 4l8 6.5V19a1.5 1.5 0 0 1-1.5 1.5H15v-5.5H9v5.5H5.5A1.5 1.5 0 0 1 4 19z"/>',
    bills: '<rect x="5" y="3" width="14" height="18" rx="3"/><path d="M9 8h6M9 12h6M9 16h3"/>',
    log: '<path d="M8.5 6H20M8.5 12H20M8.5 18H20"/><circle cx="4.5" cy="6" r="1"/><circle cx="4.5" cy="12" r="1"/><circle cx="4.5" cy="18" r="1"/>',
    more: '<path d="M4 7h9M19 7h1M4 17h1M11 17h9"/><circle cx="16" cy="7" r="2.2"/><circle cx="8" cy="17" r="2.2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    // عناصر عامة
    chevron: '<path d="m14.5 6-6 6 6 6"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
    'check-circle': '<circle cx="12" cy="12" r="8.5"/><path d="m8.5 12.3 2.4 2.4 4.6-5"/>',
    info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8v.01"/>',
    alert: '<path d="M12 4 3 19h18z"/><path d="M12 10v4M12 17v.01"/>',
    trash: '<path d="M5 7h14M10 3.5h4M7 7l1 13h8l1-13M10 11v6M14 11v6"/>',
    pencil: '<path d="m4 20 1-4L16.5 4.5a2 2 0 0 1 3 3L8 19z"/>',
    calendar: '<rect x="4" y="5" width="16" height="15" rx="3"/><path d="M4 10h16M8 3v4M16 3v4"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    'trend-down': '<path d="m4 7 6 6 3.5-3.5L20 16M20 16v-5M20 16h-5"/>',
    coins: '<circle cx="9" cy="9" r="5"/><path d="M15.5 8.2A5 5 0 1 1 8.2 15.5"/>',
    archive: '<rect x="3.5" y="4" width="17" height="4.5" rx="1.5"/><path d="M5 8.5V19a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8.5M10 13h4"/>',
    download: '<path d="M12 4v11M7.5 10.5 12 15l4.5-4.5M5 20h14"/>',
    upload: '<path d="M12 16V5M7.5 9.5 12 5l4.5 4.5M5 20h14"/>',
    shield: '<path d="M12 3.5 5 6v5.5c0 4.3 2.9 7.3 7 9 4.1-1.7 7-4.7 7-9V6z"/><path d="m9 12 2.2 2.2L15.2 10"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6 7 7M17 17l1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4"/>',
    moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
    auto: '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5a8.5 8.5 0 0 1 0 17z" fill="currentColor"/>',
    palette: '<path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.4 0 2-.9 2-1.8 0-1.2-1-1.5-1-2.7 0-1 .8-1.8 1.8-1.8H17a3.5 3.5 0 0 0 3.5-3.5C20.5 7 16.8 3.5 12 3.5z"/><circle cx="8" cy="11" r=".9"/><circle cx="11" cy="7.5" r=".9"/><circle cx="15.5" cy="8.5" r=".9"/>',
    wallet: '<path d="M4 8V6.5A2.5 2.5 0 0 1 6.5 4H17v4"/><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M16 14h1.5"/>',
    // بنود الصرف والالتزامات
    utensils: '<path d="M6 3v6a3 3 0 0 0 6 0V3M9 12v9"/><path d="M18 21V3c-2.4 1.4-3.5 4.4-3.5 8H18"/>',
    cup: '<path d="M6 5h12l-1.4 14.2a1.5 1.5 0 0 1-1.5 1.3H8.9a1.5 1.5 0 0 1-1.5-1.3z"/><path d="M6.6 10h10.8M13 5l1.6-3"/>',
    pill: '<rect x="3" y="8" width="18" height="8" rx="4" transform="rotate(-45 12 12)"/><path d="m9.2 9.2 5.6 5.6"/>',
    flame: '<path d="M12 3c.6 3 4.5 5 4.5 9.5a4.5 4.5 0 0 1-9 0c0-1.8.9-3 2-4 .2 1.5 1 2.4 2 2.6C11.6 9 11 6 12 3z"/>',
    zap: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/>',
    bus: '<rect x="4" y="4" width="16" height="13" rx="3"/><path d="M4 11h16M8 21v-2.5M16 21v-2.5"/><circle cx="8.5" cy="14.5" r=".7"/><circle cx="15.5" cy="14.5" r=".7"/>',
    phone: '<rect x="7" y="3" width="10" height="18" rx="2.5"/><path d="M11 18h2"/>',
    shirt: '<path d="M8.5 3 3.5 6.5l2 3.5L8 9v11h8V9l2.5 1 2-3.5-5-3.5a3.5 3.5 0 0 1-7 0z"/>',
    cross: '<path d="M10 3.5h4V9h5.5v4H14v7.5h-4V13H4.5V9H10z"/>',
    receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
    bag: '<path d="M5 8h14l-1 12H6z"/><path d="M9 8V6.5a3 3 0 0 1 6 0V8"/>',
    heart: '<path d="M12 20s-7.5-4.6-7.5-10.2A4.1 4.1 0 0 1 12 7.6a4.1 4.1 0 0 1 7.5 2.2C19.5 15.4 12 20 12 20z"/>',
    building: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 7.5h2M13 7.5h2M9 11.5h2M13 11.5h2M10 21v-4h4v4"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l3 3"/>',
    users: '<circle cx="9" cy="9" r="3"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0M16 6.3a3 3 0 0 1 0 5.4M17.5 14.2a5.5 5.5 0 0 1 3 4.8"/>'
  };

  // أيقونات الاختيار في تعديل البنود
  const PICKABLE = ['utensils', 'cup', 'pill', 'flame', 'zap', 'bus', 'phone', 'shirt', 'cross', 'receipt', 'bag', 'heart', 'building', 'key', 'users', 'wallet'];

  // الإيموجي القديم (من النسخ اللي فاتت) بيتحول لأيقونة من نفس المكتبة من غير ما البيانات تتغير
  const EMOJI = { '🍽️': 'utensils', '🍽': 'utensils', '🥤': 'cup', '💊': 'pill', '🔥': 'flame', '⚡': 'zap', '🚌': 'bus', '📱': 'phone', '👕': 'shirt', '⛪': 'cross', '🧾': 'receipt' };

  function resolve(name) {
    if (P[name]) return name;
    if (EMOJI[name]) return EMOJI[name];
    return null;
  }

  function svg(name, size, cls) {
    const k = resolve(name) || 'receipt';
    const s = size || 24;
    return '<svg class="i' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" width="' + s + '" height="' + s + '" aria-hidden="true" focusable="false">' + P[k] + '</svg>';
  }

  return { svg, resolve, names: Object.keys(P), PICKABLE, EMOJI };
});
